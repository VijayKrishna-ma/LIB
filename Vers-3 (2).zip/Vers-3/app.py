from flask import Flask, render_template, request, redirect, session, url_for, flash
import db
from datetime import datetime, timedelta
import numpy as np
from datetime import datetime
from collections import defaultdict

app = Flask(__name__)
app.secret_key = 'very_secret_key_for_session_management'  # Change this key later

# ========== HOME ROUTES ==========

@app.route('/')
def home():
    return redirect(url_for('student_login'))

# ========== LOGIN ROUTES ==========

@app.route('/student_login', methods=['GET', 'POST'])
def student_login():
    if request.method == 'POST':
        roll_number = request.form['roll_number']
        student = db.execute_select("SELECT * FROM lib_users WHERE roll_number = :1", (roll_number,))
        student1 = db.execute_select("SELECT * FROM lib_users")
        print(student1)
        if student:
            session['role'] = 'student'
            session['roll_number'] = roll_number
            return redirect(url_for('student_profile'))
        else:
            flash(student1)
    return render_template('student_login.html')

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['admin_username']
        password = request.form['admin_password']
        admin = db.execute_select("SELECT * FROM admin_user WHERE admin_username = :1 AND admin_password = :2", (username, password))
        if admin:
            session['role'] = 'admin'
            session['admin_username'] = username
            return redirect(url_for('admin_profile'))
        else:
            flash('Invalid Admin Credentials.', 'error')
    return render_template('admin_login.html')

# ========== STUDENT PROFILE ==========

@app.route('/student_profile')
def student_profile():
    if session.get('role') != 'student':
        return redirect(url_for('student_login'))
    
    roll_number = session['roll_number']
    student_info = db.execute_select("SELECT * FROM lib_users WHERE roll_number = :1", (roll_number,))
    loans = db.execute_select("SELECT * FROM lib_loan WHERE roll_number = :1", (roll_number,))
    return render_template('student_profile.html', student=student_info[0], loans=loans)

# ========== ADMIN PROFILE ==========

@app.route('/admin_profile', methods=['GET', 'POST'])
def admin_profile():
    if session.get('role') != 'admin':
        return redirect(url_for('admin_login'))

    if request.method == 'POST':
        roll_number = request.form['roll_number']
        book_ID = request.form['book_ID']
        start_date = datetime.now()
        end_date = start_date + timedelta(days=14)
        db.execute_query("INSERT INTO lib_loan (roll_number, book_ID, start_date, end_date, fine) VALUES (:1, :2, :3, :4, 0)", 
                         (roll_number, book_ID, start_date, end_date))

    loans = db.execute_select("""
        SELECT l.roll_number, l.book_ID, b.book_title, l.start_date, l.end_date, l.fine
        FROM lib_loan l
        JOIN lib_book b ON l.book_ID = b.book_ID
    """)
    return render_template('admin_profile.html', loans=loans)

# ========== STUDENT CATALOG ==========

@app.route('/student_catalog')
def student_catalog():
    books = db.execute_select("""
        SELECT book_title, book_author, book_category, book_edition, COUNT(book_ID) AS stock
        FROM lib_book
        GROUP BY book_title, book_author, book_category, book_edition
    """)
    return render_template('student_catalog.html', books=books)

# ========== ADMIN CATALOG ==========


@app.route('/admin_catalog', methods=['GET', 'POST'])
def admin_catalog():
    if session.get('role') != 'admin':
        return redirect(url_for('admin_login'))

    if request.method == 'POST':
        title = request.form['book_title']
        author = request.form['book_author']
        category = request.form['book_category']
        edition = request.form['book_edition']
        book_id = request.form['book_ID']
        db.execute_query("""
            INSERT INTO lib_book (book_ID, book_title, book_author, book_category, book_edition)
            VALUES (:1, :2, :3, :4, :5)
        """, (book_id, title, author, category, edition))

    books = db.execute_select("""
        SELECT 
            b.book_title,
            b.book_author,
            b.book_category,
            b.book_edition,
            COUNT(b.book_ID) AS total_stock,
            COUNT(b.book_ID) - NVL(loaned.loaned_count, 0) AS available_stock
        FROM lib_book b
        LEFT JOIN (
            SELECT 
                lb.book_title,
                lb.book_author,
                lb.book_category,
                lb.book_edition,
                COUNT(DISTINCT l.book_id) AS loaned_count
            FROM lib_loan l
            JOIN lib_book lb ON l.book_id = lb.book_id
            GROUP BY lb.book_title, lb.book_author, lb.book_category, lb.book_edition
        ) loaned
        ON b.book_title = loaned.book_title
        AND b.book_author = loaned.book_author
        AND b.book_category = loaned.book_category
        AND b.book_edition = loaned.book_edition
        GROUP BY b.book_title, b.book_author, b.book_category, b.book_edition, loaned.loaned_count
    """)

    return render_template('admin_catalog.html', books=books)


# ========== STATS PAGE ==========

@app.route('/stats')
def stats():
    book_counts = db.execute_select("""
        SELECT book_category, COUNT(*) as count
        FROM lib_book
        GROUP BY book_category
    """)
    return render_template('stats.html', book_counts=book_counts)

# ========== LOGOUT ==========

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

# ========== FINE MANAGEMENT CRON JOB ==========

@app.before_request
def calculate_fines():
    loans = db.execute_select("SELECT roll_number, book_ID, end_date FROM lib_loan")
    if loans:
        for loan in loans:
            end_date = loan['END_DATE']
            today = datetime.now()
            fine = 0
            if today > end_date:
                days_overdue = (today - end_date).days
                if days_overdue > 14:
                    fine = 5
                elif days_overdue > 7:
                    fine = 1
                else:
                    fine = 0
            db.execute_query("UPDATE lib_loan SET fine = :1 WHERE roll_number = :2 AND book_ID = :3",
                             (fine, loan['ROLL_NUMBER'], loan['BOOK_ID']))

# ========== CONTACT / COMPLAINT PAGE ==========

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if 'roll_number' not in session:
        return redirect(url_for('student_login'))

    if request.method == 'POST':
        topic = request.form['topic']
        complaint = request.form['complaint']
        roll_number = session['roll_number']
        
        db.execute_query(
            "INSERT INTO text (texts, topic, roll_number) VALUES (:1, :2, :3)",  # corrected here
            (complaint, topic, roll_number)
        )
        
        flash('Complaint submitted successfully!', 'success')
        return redirect(url_for('contact'))
    
    return render_template('contact.html')


# ========== COMPLAINT RECEIVAL PAGE ==========

# ========== COMPLAINT RECEIVAL ROUTE ==========
@app.route('/recieval')
def recieval():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('admin_login'))

    query = '''
    SELECT t.roll_number, u.name, t.topic, t.texts
    FROM text t
    JOIN lib_users u ON t.roll_number = u.roll_number
    '''
    complaints = db.execute_select(query)

    complaint_list = []
    for complaint in complaints:
        complaint_dict = {
            'ROLL_NUMBER': complaint['ROLL_NUMBER'],
            'NAME': complaint['NAME'],
            'TOPIC': complaint['TOPIC'],
            'TEXT': str(complaint['TEXTS'])  # careful: use correct column names
        }
        complaint_list.append(complaint_dict)

    return render_template('recieval.html', complaints=complaint_list)



import numpy as np
from datetime import datetime
from collections import defaultdict

@app.route('/admin_stats')
def admin_stats():
    if session.get('role') != 'admin':
        return redirect(url_for('admin_login'))
    
    # Existing data
    fines = db.execute_select('''
        SELECT roll_number, SUM(fine) AS total_fine
        FROM lib_loan
        GROUP BY roll_number
    ''')
    loans = db.execute_select('''
        SELECT roll_number, COUNT(*) AS loan_count
        FROM lib_loan
        GROUP BY roll_number
    ''')
    complaints = db.execute_select('''
        SELECT roll_number, COUNT(*) AS complaint_count
        FROM text
        GROUP BY roll_number
    ''')

    # New: get historical loan counts per book by month (last 12 months)
    loan_history = db.execute_select('''
        SELECT
            book_id,
            TO_CHAR(start_date, 'YYYY-MM') AS loan_month,
            COUNT(*) AS loan_count
        FROM lib_loan
        WHERE start_date >= ADD_MONTHS(TRUNC(SYSDATE, 'MM'), -11)
        GROUP BY book_id, TO_CHAR(start_date, 'YYYY-MM')
        ORDER BY book_id, loan_month
    ''')

    # Organize loan counts by book and month
    loans_by_book = defaultdict(lambda: defaultdict(int))  # book_id -> month -> count
    all_months = set()
    for row in loan_history:
        loans_by_book[row['BOOK_ID']][row['LOAN_MONTH']] = row['LOAN_COUNT']
        all_months.add(row['LOAN_MONTH'])
    all_months = sorted(all_months)

    # Simple future loan prediction: linear trend on monthly counts per book
    predictions = {}
    for book_id, month_data in loans_by_book.items():
        y = []
        x = list(range(len(all_months)))
        for month in all_months:
            y.append(month_data.get(month, 0))
        # Linear regression y = ax + b
        if len(x) > 1:
            coeffs = np.polyfit(x, y, 1)
            next_month_index = len(x)
            predicted_loan = max(int(coeffs[0] * next_month_index + coeffs[1]), 0)
        else:
            predicted_loan = y[0] if y else 0
        predictions[book_id] = predicted_loan

    # Get book titles for predictions
    book_titles = {}
    books = db.execute_select('SELECT book_id, book_title FROM lib_book GROUP BY book_id, book_title')
    for b in books:
        book_titles[b['BOOK_ID']] = b['BOOK_TITLE']

    # Prepare prediction list sorted by predicted loan count descending (top 5)
    predicted_demand = sorted(
        [(book_titles.get(bid, "Unknown"), pred) for bid, pred in predictions.items()],
        key=lambda x: x[1], reverse=True
    )[:5]

    # Get current stock counts per book
    stocks = db.execute_select('''
        SELECT book_id, COUNT(*) AS stock_count
        FROM lib_book
        GROUP BY book_id
    ''')
    stock_dict = {row['BOOK_ID']: row['STOCK_COUNT'] for row in stocks}

    # Future stock suggestion = current stock + predicted loan increase (simplistic)
    future_stocks = []
    for title, predicted_loan in predicted_demand:
        # Find book_id from title
        bid = next((bid for bid, t in book_titles.items() if t == title), None)
        current_stock = stock_dict.get(bid, 0)
        future_stocks.append({
            'title': title,
            'current_stock': current_stock,
            'predicted_loan': predicted_loan,
            'suggested_stock': max(current_stock, predicted_loan)  # at least predicted loan count
        })

    return render_template(
        'admin_stats.html', fines=fines, loans=loans, complaints=complaints,
        predicted_demand=predicted_demand, future_stocks=future_stocks
    )


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        roll_number = request.form['roll_number']
        name = request.form['name']
        

        existing = db.execute_select("SELECT * FROM lib_users WHERE roll_number = :1", (roll_number,))
        if existing:
            flash("Roll number already registered.")
        else:
            success = db.execute_query("INSERT INTO lib_users (roll_number, name) VALUES (:1, :2)", 
                                       (roll_number, name))
            if success:
                flash("Registration successful.")
                return redirect(url_for('student_login'))
            else:
                flash("Error occurred during registration.")
    return render_template('register.html')



@app.route('/user_home')
def user_home():
    used = db.execute_select("""
        SELECT book_title, COUNT(*) AS title_count
        FROM lib_book
        GROUP BY book_title
        ORDER BY title_count DESC
        FETCH FIRST 3 ROWS ONLY
    """) or []
    return render_template('user_home.html', used=used)

# ========== RUNNING FLASK SERVER ==========

if __name__ == '__main__':
    app.run(debug=True)
